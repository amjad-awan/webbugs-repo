const { default: axios } = require("axios");
const apiKey =
  "sk_prod_TfMbARhdgues5AuIosvvdAC9WsA5kXiZlW8HZPaRDlIbCpSpLsXBeZO7dCVZQwHAY3P4VSBPiiC33poZ1tdUj2ljOzdTCCOSpUZ_3912";

const headers = {
  Authorization: `Bearer ${apiKey}`,
  "Content-Type": "application/json",
};
const fetchResponses = async (req, res) => {
  const { formId } = req.params;
  console.log(formId)

  const { limit } = req.query;
  const queryParams = {
    limit,
  };
  const apiUrl = `https://api.fillout.com/v1/api/forms/${formId}/submissions`;
  await axios
    .get(apiUrl, { headers, params: queryParams })
    .then((response) => {
      res.json(response.data);
    })
    .catch((error) => {
      console.error("Error fetching data from Fillout API:", error);
      res.status(500).json({ error: "Failed to fetch data from Fillout API" });
    });
};

module.exports = { fetchResponses };

const express = require('express');
const { fetchResponses } = require('../controllers/fetchResponses');
const router = express.Router();
router.get('/:formId/filteredResponses', fetchResponses);

module.exports = router;
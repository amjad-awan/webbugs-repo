import React from 'react';
import ReactApexChart from 'react-apexcharts';

const Chart = ({data}) => {
  // const data = [-.2, -.4, -.42, -.6, .09,  .6, -.4, .03]; // Sample data
  // const open = [];
  // const high = [];
  // const low = [];
  // const close = [];
  
  const open = data.map(item => parseFloat(item.open));
  const high = data.map(item => parseFloat(item.high));
  const low = data.map(item => parseFloat(item.low));
  const close = data.map(item => parseFloat(item.close));
  
  console.log("High prices:", high);
  console.log("Low prices:", low);
  console.log("Close prices:", close);
  console.log("Open prices:", open);

  // Function to determine color based on value
  const getColor = (value) => {
    return value < 0 ? '#F44336' : '#2196F3'; // Red for negative values, blue for positive values
  };

  const series = [{
    name: 'Cash Flow',
    data: data,
  }];

  const categories = [
    'Nov 01, 16', 'Nov 03, 16', 'Nov 07, 16', 'Nov 09, 16', 'Nov 12, 16', 'Nov 15, 16', 'Nov 18, 16', 'Nov 21, 16',
    , // Additional date ranges
  ];

  const options = {
    chart: {
      type: 'bar',
      height: 350,
      width: 500,
      toolbar: {
        show: false,
      },
    },
    plotOptions: {
      bar: {
        columnWidth: "40%",
        colors: {
          ranges: [{
            from: -100,
            to: -46,
            color: '#F15B46'
          }, {
            from: -45,
            to: 0,
            color: '#f50a0a'
          }]
        },
        // columnWidth: '80%',
      }
    },
    dataLabels: {
      enabled: false,
    },
    yaxis: {
      max: 0.8,
      min: -0.4,
      crosshairs: {
        show: false,
      },
      labels: {
        formatter: function (y) {
          return y.toFixed(1); // Format y-axis labels to one decimal place
        },
      },
      axisBorder: {
        show: true,
        color: '#78909C',
        height: '100%',
        width: 1,
        offsetX: 0,
        offsetY: 0,
      },
      axisTicks: {
        show: true,
        borderType: 'solid',
        color: '#78909C',
        height: 6,
        offsetX: 0,
        offsetY: 0,
      },
      opposite: true,
    },
    xaxis: {
      type: 'category',
      categories: categories,
      position: 'top',
      labels: {
        rotate: -90,
        position: 'top',
      },
      tickPlacement: 'on',
      axisTicks: {
        show: true,
        borderType: 'solid',
        color: '#78909C',
        height: 4,
        offsetX: 0,
        offsetY: 0,
      },
      axisBorder: {
        show: true,
        color: '#78909C',
        height: 1,
        width: '100%',
        offsetX: 0,
        offsetY: 0,
      },
      crosshairs: {
        show: true,
      },
      title: {
        style: {
          fontSize: '12px',
          fontWeight: 'bold',
          fontFamily: 'Arial, sans-serif',
        },
      },
      annotations: {
        xaxis: [
          {
            x: 0,
            borderColor: '#000',
            borderWidth: 1,
            strokeDashArray: 0,
            label: {
              borderColor: '#000',
              borderWidth: 1,
              text: '0',
              textAnchor: 'start',
              position: 'top',
              offsetX: 5,
              offsetY: 5,
              style: {
                color: '#000',
                background: '#fff',
                fontSize: '12px',
                fontWeight: 'bold',
                padding: {
                  left: 5,
                  right: 5,
                  top: 2,
                  bottom: 2,
                },
              },
            },
          },
        ],
      },
   
    },

    grid: {
      show: true,
      borderColor: '#78909C',
      strokeDashArray: false,
      position: 'front',
      xaxis: {
        lines: {
          show: true,
        },
      },
      yaxis: {
        lines: {
          show: false,
        },
      },
      padding: {
        top: 0,
        right: 0,
        bottom: 0,
        left: 0,
      },
    },
    annotations: {
      yaxis: [{
        y: 0,
        width: '100%',
      }],
      xaxis: [{
        x: 0,
        width: '100%',
      
      }]
    }
  };

  return (
    <div>
      <ReactApexChart options={options} series={series} type="bar" height={350} />
    </div>
  );
};

export default Chart;

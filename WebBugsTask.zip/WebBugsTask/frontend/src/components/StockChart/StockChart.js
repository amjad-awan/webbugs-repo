import React from "react";
import ReactApexChart from "react-apexcharts";

const StockChart = ({ data }) => {
  const open = data.map((item) => parseFloat(item.open));
  const high = data.map((item) => parseFloat(item.high));
  const low = data.map((item) => parseFloat(item.low));
  const close = data.map((item) => parseFloat(item.close));

  const chartData = [
    {
      name: "Open",
      data: open,
    },
    {
      name: "High",
      data: high,
    },
    {
      name: "Low",
      data: low,
    },
    {
      name: "Close",
      data: close,
    },
  ];

  const chartOptions = {
    chart: {
      type: "bar",
      height: 350,
      toolbar: {
        show: false,}
    },

    xaxis: {
      categories: [
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
        "Sunday",
      ],
    },
    yaxis: {
      title: {
        text: "Price",
      },
    },
    fill: {
      opacity: 1,
    },
    dataLabels: {
      enabled: false,
    },
    tooltip: {
      y: {
        formatter: function (val) {
          return "$" + val.toFixed(2);
        },
      },
    },
    title: {
      text: "weekly stock exchange information",
      align: "center",
      margin: 10,
      offsetX: 0,
      offsetY: 0,
      floating: false,
      style: {
        margin: "300px",
        fontSize: "14px",
        fontWeight: "bold",
        fontFamily: undefined,
        color: "#263238",
      },
    },
  };

  return (
    <ReactApexChart
      options={chartOptions}
      series={chartData}
      type="bar"
      height={350}
    />
  );
};

export default StockChart;

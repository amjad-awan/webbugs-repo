import React, { useEffect, useState } from "react";
import "./App.css";
import Chart from "./components/Chart/Chart";

import StockChart from "./components/StockChart/StockChart";

function App() {
  const [data, setData] = useState(null);

  const fetchData = async () => {
    try {
      const response = await fetch(
        "https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=000002.SHZ&outputsize=full&apikey=demo"
      );
      const jsonData = await response.json();
      setData(jsonData);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };
  const StockDailyData = data
    ? Object.entries(data["Time Series (Daily)"]).map(
        ([timestamp, values]) => ({
          open: values["1. open"],
          high: values["2. high"],
          low: values["3. low"],
          close: values["4. close"],
          volume: values["5. volume"],
        })
      )
    : [];

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div className="App">
      <StockChart data={StockDailyData?.slice(0, 7)} />
    </div>
  );
}

export default App;
